import { Button, Form, Modal } from "react-bootstrap";
import { RootState } from '../../main';
import React, { Component } from "react";
import { connect } from "react-redux";

interface CreateDegreeCourseDialogState {
  showModal: boolean;
  name: string;
  shortName: string;
  universityName: string;
  universityShortName: string;
  departmentName: string;
  departmentShortName: string;
  error: string | null;
  isLoading: boolean;
}

interface PropsFromRedux {
  token: string | null;
}

interface OwnProps {
  createSuccess: () => Promise<void>
}

type CreateDegreeCourseDialogProps = PropsFromRedux & OwnProps;

class CreateDegreeCourseDialog extends Component <CreateDegreeCourseDialogProps, CreateDegreeCourseDialogState>{
  state = {
    showModal: false,
    name: '',
    shortName:'',
    universityName:'',
    universityShortName: '',
    departmentName: '',
    departmentShortName:'',
    error: null as string | null,
    isLoading: false
  };

  baseUrl: string = import.meta.env.VITE_API_BASE_URL;
  course_URL: string = this.baseUrl + "degreeCourses";
    

  handleShow = () => {
    this.setState({ showModal: true });
  };

  handleClose = () => {
    this.setState({ showModal: false });
  };

  handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ name: e.target.value });
  };

  handleShortNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ shortName: e.target.value });
  };

  handleuniversityNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ universityName: e.target.value });
  };

  handleuniversityShortNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ universityShortName: e.target.value });
  };

   handledepartmentNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ departmentName: e.target.value });
  };
   handledepartmentShortNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ departmentShortName: e.target.value });
  };
  
  

  handleCreateCourse: () => Promise <void> = async () => {

    this.setState({isLoading: true});
    const token: string = this.props.token;

  try {

  const response: Response = await fetch(this.course_URL, {
    method: 'POST',
    headers: {'Authorization': token || '',
              'Content-Type': 'application/json'
    },
    body: JSON.stringify({name: this.state.name,
                          shortName: this.state.shortName,
                          universityName: this.state.universityName,
                          universityShortName: this.state.universityShortName,
                          departmentName: this.state.departmentName,
                          departmentShortName: this.state.departmentShortName
    })
    
  });

    console.log('Response Status:', response.status);
    console.log('Response OK?', response.ok);

    if(response.ok) {

      if (this.props.createSuccess) {
        this.props.createSuccess();
      }

      this.setState({isLoading: false});
      
      this.handleClose();
    }
    else {
      const errorText: string = await response.text();
      console.error('Erstellen fehlgeschlagen:', response.status, errorText);
      
      this.setState({ 
        error: `Erstellen fehlgeschlagen: ${response.status} - ${errorText}`,
      });

      this.setState({isLoading: false});
    }

    
}catch(error: any) {
      console.error('Erstellen fehlgeschlagen:', error);
    };
};

 render() {
    const { error, isLoading } = this.state;
    return (

        <div id = "createDegreeCourseContainer">
          <Button id = "DegreeCourseManagementPageCreateDegreeCourseButton" variant="primary" onClick={this.handleShow}>
            Neuen Studiengang erstellen
          </Button>
        <Modal id = "DegreeCourseManagementPageCreateComponent" show={this.state.showModal} onHide={this.handleClose}>
          
          <Modal.Header closeButton>
            <Modal.Title>Neuen Studiengang erstellen</Modal.Title>
          </Modal.Header>
          
          <Modal.Body>
            {error && (
              <div className="alert alert-danger">
                <strong>Fehler!</strong> {error}
              </div>
            )}
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>Name</Form.Label>
                <Form.Control id = "CreateDegreeCourseComponentEditName"
                  type="text"
                  placeholder="Name eingeben"
                  value={this.state.name}
                  onChange={this.handleNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Name kurz</Form.Label>
                <Form.Control id = "CreateDegreeCourseComponentEditShortName"
                  type="text"
                  placeholder="Kurznamen eingeben"
                  value={this.state.shortName}
                  onChange={this.handleShortNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Universität</Form.Label>
                <Form.Control id = "CreateDegreeCourseComponentEditUniversityName"
                  type="text"
                  placeholder="Universitätsnamen eingeben"
                  value={this.state.universityName}
                  onChange={this.handleuniversityNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Universität kurz</Form.Label>
                <Form.Control id ="CreateDegreeCourseComponentEditUniversityShortName"
                  type="text"
                  placeholder="Universitäts-Kurznamen eingeben"
                  value={this.state.universityShortName}
                  onChange={this.handleuniversityShortNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Fachbereich</Form.Label>
                <Form.Control id ="CreateDegreeCourseComponentEditDepartmentName"
                  type="text"
                  placeholder="Fachbereich eingeben"
                  value={this.state.departmentName}
                  onChange={this.handledepartmentNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

               <Form.Group className="mb-3">
                <Form.Label>Fachbereich kurz</Form.Label>
                <Form.Control id ="CreateDegreeCourseComponentEditDepartmentShortName"
                  type="text"
                  placeholder="Fachbereich Kurzname eingeben"
                  value={this.state.departmentShortName}
                  onChange={this.handledepartmentShortNameChange}
                  disabled={isLoading}
                />
              </Form.Group>
            </Form>

             {isLoading && (
              <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-2">Erstellung wird durchgeführt...</p>
              </div>
            )}
          </Modal.Body>

          <Modal.Footer>
            <Button id= "OpenDegreeCourseManagementPageListComponentButton" variant="secondary" onClick={this.handleClose}>
              Abbrechen
            </Button>
            <Button id ="CreateDegreeCourseComponentCreateDegreeCourseButton" variant="primary" onClick={this.handleCreateCourse}>
              Studiengang erstellen
            </Button>
          </Modal.Footer>
          
        </Modal>
        </div>
    );
}
}
const mapStateToProps = (state: RootState) => ({
  token: state.auth.token
});

export default connect(mapStateToProps)(CreateDegreeCourseDialog);