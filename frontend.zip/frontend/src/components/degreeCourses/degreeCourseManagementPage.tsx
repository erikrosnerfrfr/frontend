import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../../main';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import CreateDegreeCourseDialog from './createDegreeCourseDialog';
import UpdateDegreeCourseDialog from './updateDegreeCourseDialog';

import CreateDegreeCourseApplication from '../degreeCourseApplications/createDegreeCourseApplication';
import { Card } from 'react-bootstrap';

interface DegreeCourse {
    name: string;
    shortName: string;
    universityName: string;
    universityShortName: string;
    departmentName: string;
    departmentShortName: string;
    id: string;
}

const DegreeCourseManagementPage: React.FC = () => {
  const [courses, setCourses] = useState<DegreeCourse[]>([]);
  const [loading, setLoading] = useState(true);
  const token: string = useSelector((state: RootState) => state.auth.token);
  const isAdmin: boolean = useSelector((state: RootState) => state.auth.isAdministrator);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [courseToDelete, setCourseToDelete] = useState<DegreeCourse | null>(null);
  const [deleting, setDeleting] = useState(false);

  const baseUrl: string = import.meta.env.VITE_API_BASE_URL;
  const courseUrl: string = baseUrl + "degreeCourses";


  useEffect(() => {
    fetchCourses();
  }, []);

   const openDeleteModal = (course: DegreeCourse) => {
    setCourseToDelete(course);
    setShowDeleteModal(true);
  };
  
  const closeDeleteModal: () => void = () => {
    setShowDeleteModal(false);
    setCourseToDelete(null);
    setDeleting(false);
  };

  const fetchCourses = async () => {
    setLoading(true);

    const response = await fetch(courseUrl, {
        method: 'GET',
        headers: { 
          'Authorization': token || '',
          'Content-Type': 'application/json'
        },
      });

  const data = await response.json();
  setCourses(data);
      setLoading(false);
  }
  

  const handleDeleteCourse = async (id: string) => {
    
        setLoading(true);

        const response = await fetch(courseUrl+'/'+id, {
            method: 'DELETE',
            headers: { 
            'Authorization': token || ''
            },
        });
        console.log(response);
        await fetchCourses();
        setLoading(false);
        closeDeleteModal();
  };
  
  if (loading) {
    return <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-2">DegreeCourse Management wird geladen...</p>
              </div>;
  }
  
  return (
    <div id="DegreeCourseManagementPage">
      <h1>Studiengang-Management</h1>
        {isAdmin && <CreateDegreeCourseDialog createSuccess={fetchCourses}/>}
      <hr></hr>
      <div id= "DegreeCourseManagementPageListComponent">
        <div >
          <h5 className='text-start'>Studiengangs-Liste</h5>
          {courses.length < 1 &&
          <h6 className='text-start'> Es gibt noch keine Kurse</h6>}    
          <div className="row">
            {courses.map(course => (
              <div 
                className="col-12 col-md-6 col-lg-4 mb-3" 
                key={course.id}
                id={`DegreeCourseItem${course.id}`}
              >
                <Card className="h-100 text-center p-0">
                  <Card.Header>
                    <Card.Title>
                      <span>{course.shortName}: </span> <span>{course.name}</span>
                    </Card.Title>
                  </Card.Header>
                  <Card.Body className='text-start'>
                    
                    
                    <Card.Text>
                      <strong>Universität:</strong> <span id="UniversityName">{course.universityName}</span>
                    </Card.Text>

                    <Card.Text>
                      <strong>Fachbereich:</strong> <span id="DepartmentName">{course.departmentName}</span>
                    </Card.Text>

                    <Card.Text>
                      <strong>Studiengang:</strong> <span id="Name">{course.name}</span>
                    </Card.Text>
                    
                  </Card.Body>
                  
                  <Card.Footer className="d-flex justify-content-left align-items-center gap-2 flex-wrap">
                    {isAdmin && <UpdateDegreeCourseDialog 
                      id={course.id}
                      name={course.name}
                      shortName={course.shortName}
                      universityName={course.universityName}
                      universityShortName={course.universityShortName}
                      departmentName={course.departmentName}
                      departmentShortName={course.departmentShortName}
                      updateSuccess = {fetchCourses}
                    />}
                    
                    {isAdmin && <button
                                id={`DegreeCourseItemDeleteButton${course.id}`}
                                className="btn btn-sm btn-outline-danger"
                                onClick={() => openDeleteModal(course)}
                              >Löschen
                              </button>}

                              <CreateDegreeCourseApplication  
                                propCourseID={course.id}
                                propCourseName={course.name}
                                createSuccess={fetchCourses}
                              />
                  </Card.Footer>
                </Card>               
              </div>
            ))}
          </div>
        </div>
      </div>

      <Modal id = {`DeleteDialogDegreeCourse${courseToDelete?.id}`} show={showDeleteModal} onHide={closeDeleteModal}>
        {courseToDelete && (
          <div>
          <Modal.Header closeButton>
            <Modal.Title>Studiengang {courseToDelete.shortName}: {courseToDelete.name} wirklich löschen?</Modal.Title>
          </Modal.Header>
          
          <Modal.Body>
            <small>diese Aktion ist nicht rückgängig zu machen!</small>

             {deleting && (
              <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Lädt...</span>
                </div>
                <p className="mt-2">Löschvorgang wird durchgeführt...</p>
              </div>
            )}
          </Modal.Body>

          <Modal.Footer>
            <Button id= "DeleteDialogCancelButton" variant="secondary" onClick={closeDeleteModal}>
              Abbrechen
            </Button>
            <Button id ="DeleteDialogConfirmButton" variant="primary" onClick={()=>handleDeleteCourse(courseToDelete.id)}>
              Löschen
            </Button>
          </Modal.Footer>
        </div>
        )}       
      </Modal>
    </div>
    
  );
};

export default DegreeCourseManagementPage;