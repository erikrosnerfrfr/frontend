import { Button, Form, Modal } from "react-bootstrap";
import { RootState } from '../../main';
import React, { Component } from "react";
import { connect } from "react-redux";

interface UpdateDegreeCourseDialogState {
  showModal: boolean;
  id: string;
  name: string;
  shortName: string;
  universityName: string;
  universityShortName: string;
  departmentName: string;
  departmentShortName: string;
  error: string | null;
  isLoading: boolean;
}

interface PropsFromRedux {
  token: string | null;
}

interface OwnProps {
  updateSuccess: () => Promise<void>;
  name: string | null;
  id: string;
  shortName: string | null;
  universityName: string | null;
  universityShortName: string | null;
  departmentName: string | null;
  departmentShortName: string | null;
}

type UpdateDegreeCourseDialogProps = PropsFromRedux & OwnProps;

class UpdateDegreeCourseDialog extends Component <UpdateDegreeCourseDialogProps, UpdateDegreeCourseDialogState>{
  state = {
    showModal: false,
    name: this.props.name,
    id: this.props.id,
    shortName:this.props.shortName,
    universityName:this.props.universityName,
    universityShortName: this.props.universityShortName,
    departmentName: this.props.departmentName,
    departmentShortName: this.props.departmentShortName,
    error: null as string | null,
    isLoading: false
  };


  baseUrl: string = import.meta.env.VITE_API_BASE_URL;
  updateCourse_URL = this.baseUrl + "degreeCourses/" + this.props.id;
    

  handleShow = () => {
    this.setState({ showModal: true });
  };

  handleClose = () => {
    this.setState({ showModal: false });
  };

   handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ name: e.target.value });
    };
  
    handleShortNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ shortName: e.target.value });
    };
  
    handleuniversityNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ universityName: e.target.value });
    };
  
    handleuniversityShortNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ universityShortName: e.target.value });
    };
  
     handledepartmentNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ departmentName: e.target.value });
    };
     handledepartmentShortNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ departmentShortName: e.target.value });
    };
  

  handleUpdateCourse = async () => {

    this.setState({isLoading: true});
    const token = this.props.token;

  try {

  const response = await fetch(this.updateCourse_URL, {
    method: 'PUT',
    headers: {'Authorization': token || '',
              'Content-Type': 'application/json'
    },
    body: JSON.stringify({name: this.state.name,
                          shortName: this.state.shortName,
                          universityName: this.state.universityName,
                          universityShortName: this.state.universityShortName,
                          departmentName: this.state.departmentName,
                          departmentShortName: this.state.departmentShortName
    })
    
  });

    console.log('Response Status:', response.status);
    console.log('Response OK?', response.ok);

    if(response.ok) {

      if (this.props.updateSuccess) {
        this.props.updateSuccess();
      }

      this.setState({isLoading: false});
      
      this.handleClose();
      alert("Studiengang erfolgreich bearbeitet");
    }
    else {
      const errorText = await response.text();
      console.error('Bearbeitung fehlgeschlagen:', response.status, errorText);
      
      this.setState({ 
        error: `Bearbeitung fehlgeschlagen: ${response.status} - ${errorText}`,
      });

      this.setState({isLoading: false});
    }

    
}catch(error: any) {
      console.error('Login fehlgeschlagen:', error);
    };
};

 render() {
    const { error, isLoading } = this.state;
    return (

        <div id = "updateDegreeCourseContainer">
          <Button id={`DegreeCourseItemEditButton${this.props.id}`} variant="primary" onClick={this.handleShow}>
            bearbeiten
          </Button>
        <Modal id = "DegreeCourseManagementPageEditComponent" show={this.state.showModal} onHide={this.handleClose}>
          
          <Modal.Header closeButton>
            <Modal.Title>Bearbeiten des Studiengangs {this.state.name}</Modal.Title>
          </Modal.Header>
          
          <Modal.Body>
            {error && (
              <div className="alert alert-danger">
                <strong>Fehler!</strong> {error}
              </div>
            )}
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>Name</Form.Label>
                <Form.Control id = "EditDegreeCourseComponentEditName"
                  type="text"
                  placeholder="Name eingeben"
                  value={this.state.name}
                  onChange={this.handleNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Kurzname</Form.Label>
                <Form.Control id = "EditDegreeCourseComponentEditShortName"
                  type="text"
                  placeholder="Kurzname eingeben"
                  value={this.state.shortName}
                  onChange={this.handleShortNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Universität</Form.Label>
                <Form.Control id = "EditDegreeCourseComponentEditUniversityName"
                  type="text"
                  placeholder="Uniname eingeben"
                  value={this.state.universityName}
                  onChange={this.handleuniversityNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Universität Kurzname</Form.Label>
                <Form.Control id = "EditDegreeCourseComponentEditUniversityShortName"
                  type="text"
                  placeholder="Unikurzname eingeben"
                  value={this.state.universityShortName}
                  onChange={this.handleuniversityShortNameChange}
                  disabled={isLoading}
                />
              </Form.Group><Form.Group className="mb-3">
                <Form.Label>Fachbereich</Form.Label>
                <Form.Control id = "EditDegreeCourseComponentEditDepartmentName"
                  type="text"
                  placeholder="Fachbereich eingeben"
                  value={this.state.departmentName}
                  onChange={this.handledepartmentNameChange}
                  disabled={isLoading}
                />
              </Form.Group><Form.Group className="mb-3">
                <Form.Label>Fachbereichkurzname</Form.Label>
                <Form.Control id = "EditDegreeCourseComponentEditDepartmentShortName"
                  type="text"
                  placeholder="Fachbereich Kurzname eingeben"
                  value={this.state.departmentShortName}
                  onChange={this.handledepartmentShortNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              
            </Form>

             {isLoading && (
              <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-2">Bearbeitung wird durchgeführt...</p>
              </div>
            )}
          </Modal.Body>

          <Modal.Footer>
            <Button id= "OpenDegreeCourseManagementPageListComponentButton" variant="secondary" onClick={this.handleClose}>
              Abbrechen
            </Button>
            <Button id ="EditDegreeCourseComponentSaveDegreeCourseButton" variant="primary" onClick={this.handleUpdateCourse}>
              Bearbeitung speichern
            </Button>
          </Modal.Footer>
          
        </Modal>
        </div>
    );
}
}
const mapStateToProps = (state: RootState) => ({
  token: state.auth.token
});

export default connect(mapStateToProps)(UpdateDegreeCourseDialog);