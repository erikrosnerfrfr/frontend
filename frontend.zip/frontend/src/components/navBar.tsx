import React from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

import LogoutButton from "./login_logout/logoutButton";
import { RootState } from "../main";

const NavBar: React.FC = () => {
  const isAdmin = useSelector(
    (state: RootState) => state.auth.isAdministrator
  );


  return (
    <div className = "fixed-top bg-white border-bottom shadow-sm p-2 d-flex justify-content-center">
      <div className="d-flex flex-column flex-md-row btn-group-responsive w-100 w-md-auto" role="group" aria-label="Navigation">
          <Link
            to="/home"
            id="OpenStartPageButton"
            className="btn btn-primary"
          >
            Startseite
          </Link>

          {isAdmin && (
            <Link
              to="/userManagement"
              id="OpenUserManagementPageButton"
              className="btn btn-outline-primary"
            >
              User Management
            </Link>
          )}

          
            <Link
              to="/degreeCourseManagement"
              id="OpenDegreeCourseManagementPageButton"
              className="btn btn-outline-primary"
            >
              Studiengänge
            </Link>

          
            <Link
              to="/degreeCourseApplicationManagement"
              id="OpenDegreeCourseApplicationManagementPageButton"
              className="btn btn-outline-primary"
            >
              Studienbewerbungen
            </Link>

          <LogoutButton />

       </div>
    </div>
  );
};

export default NavBar;
