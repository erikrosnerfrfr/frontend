import reactLogo from '../assets/react.svg'
import viteLogo from '/vite.svg'
import { Component } from "react";
import { logout } from '../slices/authSlice';
import { connect } from 'react-redux';
import { RootState } from '../store/configureStore';
import CurrentUserProfile from './currentUserProfile/currentUserProfile';

interface PropsFromRedux {
  userID: string | null
  token: string | null
  logout: () => void
}

interface HomePageProps extends PropsFromRedux {}

class HomePage extends  Component<HomePageProps> {

    handleLogout = async () => {
        this.props.logout();
    };

  render() {
    return (
        <div id ="StartPage">
    <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Willkommen, {this.props.userID}.</h1>
      <h1>Du bist jetzt eingeloggt.</h1>

      <CurrentUserProfile/>

        <p>Dies ist ein simples Studienportal zum Verwalten von</p>
        <p>Nutzern, Studiengängen und Bewerbungen.</p>
        <p>Zur Navigation nutzen Sie bitte die oben aufgeführten Links.</p>
        <p>Um mehr über das Projekt zu erfahren,</p>
        <p>klicken Sie auf die Icons.</p>
        <small>Zur Designhilfe wurde in Bezug auf </small>
        <small>className-Attribute und Responsivität </small>
        <small>Google Gemini verwendet.</small>
        <p><small>Für ein kleines Profil wurde einmalig publicUsers aufgerufen.</small></p>
        <p><small>Zusätzlich wurde die Bearbeitung von Studienbewerbungen umgesetzt.</small></p>
      </div>
  )
}
}

const mapStateToProps = (state: RootState) => ({
  userID: state.auth.userID,
  token: state.auth.token
});

const mapDispatchToProps = {
  logout
};

export default connect(
  mapStateToProps,
  mapDispatchToProps 
)(HomePage);
