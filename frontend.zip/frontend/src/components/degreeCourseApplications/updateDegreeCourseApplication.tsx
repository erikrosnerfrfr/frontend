import { Button, Form, Modal } from "react-bootstrap";
import { RootState } from '../../main';
import React, { Component } from "react";
import { connect } from "react-redux";

interface UpdateDegreeCourseApplicationDialogState {
  showModal: boolean;
  id: string;
  userID: string;
  degreeCourseID: string;
  targetPeriodYear: string;
  targetPeriodShortName: string;
  error: string | null;
  isLoading: boolean;
}

interface PropsFromRedux {
  token: string | null;
}

interface OwnProps {
  updateSuccess: () => Promise<void>;
  name: string | null;
  id: string;
  userID: string;
  degreeCourseID: string;
  targetPeriodYear: string;
  targetPeriodShortName: string;
}

type UpdateDegreeCourseApplicationDialogProps = PropsFromRedux & OwnProps;

class UpdateDegreeCourseApplicationDialog extends Component <UpdateDegreeCourseApplicationDialogProps, UpdateDegreeCourseApplicationDialogState>{
  state = {
    showModal: false,
    name: this.props.name,
    id: this.props.id,
    userID:this.props.userID,
    degreeCourseID:this.props.degreeCourseID,
    targetPeriodYear: this.props.targetPeriodYear,
    targetPeriodShortName: this.props.targetPeriodShortName,
    targetPeriodName: this.props.targetPeriodShortName === 'WiSe' 
    ? 'Wintersemester' 
    : 'Sommersemester',
    error: null as string | null,
    isLoading: false
  };


  baseUrl: string = import.meta.env.VITE_API_BASE_URL;
  updateApplication_URL = this.baseUrl + "degreeCourseApplications/" + this.props.id;
    
  handleShow = () => {
    this.setState({ showModal: true });
  };

  handleClose = () => {
    this.setState({ showModal: false });
  };

   handletargetPeriodYearChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ targetPeriodYear: e.target.value });
    };
  
    handletargetPeriodShortNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ targetPeriodShortName: e.target.value });
    }; 

  handleUpdateApplication = async () => {

    this.setState({isLoading: true});
    const token = this.props.token;

  try {

  const response = await fetch(this.updateApplication_URL, {
    method: 'PUT',
    headers: {'Authorization': token || '',
              'Content-Type': 'application/json'
    },
    body: JSON.stringify({targetPeriodYear: this.state.targetPeriodYear,
                          targetPeriodShortName: this.state.targetPeriodShortName
    })
    
  });

    console.log('Response Status:', response.status);
    console.log('Response OK?', response.ok);

    if(response.ok) {

      if (this.props.updateSuccess) {
        this.props.updateSuccess();
      }

      this.setState({isLoading: false});
      
      this.handleClose();
      alert("Bewerbung erfolgreich bearbeitet");
    }
    else {
      const errorText = await response.text();
      console.error('Bearbeitung fehlgeschlagen:', response.status, errorText);
      
      this.setState({ 
        error: `Bearbeitung fehlgeschlagen: ${response.status} - ${errorText}`,
      });

      this.setState({isLoading: false});
    }

    
}catch(error: any) {
      console.error('Login fehlgeschlagen:', error);
    };
};

 render() {
    const { error, isLoading } = this.state;
    return (

        <div id = "updateDegreeCourseApplicationContainer">
          <Button id={`DegreeCourseApplicationItemEditButton${this.props.id}`} variant="primary" onClick={this.handleShow}>
            bearbeiten
          </Button>
        <Modal id = "DegreeCourseApplicationManagementPageEditComponent" show={this.state.showModal} onHide={this.handleClose}>
          
          <Modal.Header closeButton>
            <Modal.Title>Bearbeiten der Bewerbung: {this.state.name}</Modal.Title>
          </Modal.Header>
          
          <Modal.Body>
            {error && (
              <div className="alert alert-danger">
                <strong>Fehler!</strong> {error}
              </div>
            )}
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>User</Form.Label>
                <Form.Control id = "EditDegreeCourseApplicationComponentEditUserID"
                  type="text"
                  placeholder="UserID eingeben"
                  value={this.props.userID}
                  disabled={true}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>StudiengangsID</Form.Label>
                <Form.Control id = "EditDegreeCourseApplicationComponentEditDegreeCourseID"
                  type="text"
                  placeholder="KursID eingeben"
                  value={this.props.degreeCourseID}
                  disabled={true}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Jahr</Form.Label>
                <Form.Control id = "EditDegreeCourseApplicationComponentEditTargetPeriodYear"
                  type="text"
                  placeholder="Jahr eingeben"
                  value={this.state.targetPeriodYear}
                  onChange={this.handletargetPeriodYearChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                    <Form.Label>Semester</Form.Label>
                        <Form.Control id ="UpdateDegreeCourseApplicationComponentEditTargetPeriodName" as = "select" name = "targetPeriodShortName" area-label = "Default select example" 
                            onChange={this.handletargetPeriodShortNameChange}
                            disabled={isLoading}>
                            <option value = {this.state.targetPeriodShortName}>{this.state.targetPeriodName}</option>
                            <option value = "WiSe">Wintersemester</option>
                            <option value = "SoSe">Sommersemester</option>
                        </Form.Control>
                    </Form.Group> 
            </Form>

             {isLoading && (
              <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-2">Bearbeitung wird durchgeführt...</p>
              </div>
            )}
          </Modal.Body>

          <Modal.Footer>
            <Button id= "OpenDegreeCourseApplicationManagementPageListComponentButton" variant="secondary" onClick={this.handleClose}>
              Abbrechen
            </Button>
            <Button id ="EditDegreeCourseApplicationComponentSaveDegreeCourseApplicationButton" variant="primary" onClick={this.handleUpdateApplication}>
              Bearbeitung speichern
            </Button>
          </Modal.Footer>
          
        </Modal>
        </div>
    );
}
}
const mapStateToProps = (state: RootState) => ({
  token: state.auth.token
});

export default connect(mapStateToProps)(UpdateDegreeCourseApplicationDialog);