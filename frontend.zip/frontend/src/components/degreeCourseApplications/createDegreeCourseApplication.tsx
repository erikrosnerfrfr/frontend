import { Button, Form, Modal } from "react-bootstrap";
import { RootState } from '../../main';
import React, { Component } from "react";
import { connect } from "react-redux";

interface CreateDegreeCourseApplicationDialogState {
  showModal: boolean;
  applicantUserID: string;
  degreeCourseID: string;
  targetPeriodYear: string;
  targetPeriodShortName: string;
  error: string | null;
  isLoading: boolean;
}

interface PropsFromRedux {
  token: string | null;
  isAdministrator: boolean;
  userID: string;
}

interface OwnProps {
  createSuccess: () => Promise<void>
  propCourseID: string;
  propCourseName: string;
}

type CreateDegreeCourseApplicationDialogProps = PropsFromRedux & OwnProps;

class CreateDegreeCourseApplicationDialog extends Component <CreateDegreeCourseApplicationDialogProps, CreateDegreeCourseApplicationDialogState>{
  state = {
    showModal: false,
    applicantUserID: this.props.userID,
    degreeCourseID: '',
    targetPeriodYear: '',
    targetPeriodShortName: '',
    error: null as string | null,
    isLoading: false
  };

  baseUrl: string = import.meta.env.VITE_API_BASE_URL;
  application_URL: string = this.baseUrl + "degreeCourseApplications";
    

  handleShow = () => {
    this.setState({ showModal: true });
  };

  handleClose = () => {
    this.setState({ showModal: false });
  };

  handleapplicantUserIDChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ applicantUserID: e.target.value });
  };

  handledegreeCourseIDChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ degreeCourseID: e.target.value });
  };

  handletargetPeriodYearChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ targetPeriodYear: e.target.value });
  };

  handletargetPeriodShortNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ targetPeriodShortName: e.target.value });
  };
  
  

  handleCreateApplication: () => Promise <void> = async () => {

    this.setState({isLoading: true});
    const token: string = this.props.token;

  try {

  const response: Response = await fetch(this.application_URL, {
    method: 'POST',
    headers: {'Authorization': token || '',
              'Content-Type': 'application/json'
    },
    body: JSON.stringify({  applicantUserID: this.state.applicantUserID,
                            degreeCourseID: this.props.propCourseID,
                            targetPeriodYear: this.state.targetPeriodYear,
                            targetPeriodShortName: this.state.targetPeriodShortName
    })
    
  });

    console.log('Response Status:', response.status);
    console.log('Response OK?', response.ok);

    if(response.ok) {

      if (this.props.createSuccess) {
        this.props.createSuccess();
      }

      this.setState({isLoading: false});
      
      this.handleClose();
    }
    else {
      const errorText: string = await response.text();
      console.error('Erstellen fehlgeschlagen:', response.status, errorText);
      
      this.setState({ 
        error: `Erstellen fehlgeschlagen: ${response.status} - ${errorText}`,
      });

      this.setState({isLoading: false});
    }

    
}catch(error: any) {
      console.error('Erstellen fehlgeschlagen:', error);
    };
};

 render() {
    const { error, isLoading } = this.state;
    return (

        <div id = "createDegreeCourseApplicationContainer">
          <Button id = {"CreateDegreeCourseApplicationForDegreeCourse"+this.props.propCourseID} onClick={this.handleShow}>
            Bewerbung anlegen
          </Button>
        <Modal id = "DegreeCourseApplicationManagementPageCreateComponent" show={this.state.showModal} onHide={this.handleClose}>
          
          <Modal.Header closeButton>
            <Modal.Title>Bewerbung anlegen zum Kurs: {this.props.propCourseName}</Modal.Title>
          </Modal.Header>
          
          <Modal.Body>
            {error && (
              <div className="alert alert-danger">
                <strong>Fehler!</strong> {error}
              </div>
            )}
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>Studiengang</Form.Label>
                <Form.Control id = "CreateDegreeCourseApplicationEditDegreeCourseID"
                  type="text"
                  placeholder="Studiengangs-ID eingeben"
                  value={this.props.propCourseID}
                  onChange={this.handledegreeCourseIDChange}
                  disabled={true}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>UserID</Form.Label>
                <Form.Control id = "CreateDegreeCourseApplicationEditUserID"
                  type="text"
                  placeholder="UserID eingeben"
                  value={this.state.applicantUserID}
                  onChange={this.handleapplicantUserIDChange}
                  disabled={!this.props.isAdministrator}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Jahr</Form.Label>
                <Form.Control id = "CreateDegreeCourseApplicationEditTargetPeriodYear"
                  type="text"
                  placeholder="Jahr eingeben"
                  value={this.state.targetPeriodYear}
                  onChange={this.handletargetPeriodYearChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Semester</Form.Label>
                <Form.Control id ="CreateDegreeCourseApplicationEditTargetPeriodName" as = "select" name = "targetPeriodShortName" area-label = "Default select example" 
                  onChange={this.handletargetPeriodShortNameChange}
                  disabled={isLoading}>
                  <option value = "">Bitte Semester auswählen</option>
                  <option value = "WiSe">Wintersemester</option>
                  <option value = "SoSe">Sommersemester</option>
                </Form.Control>
              </Form.Group>
            </Form>

             {isLoading && (
              <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-2">Login wird durchgeführt...</p>
              </div>
            )}
          </Modal.Body>

          <Modal.Footer>
            <Button id= "OpenDegreeCourseManagementPageListComponentButton" variant="secondary" onClick={this.handleClose}>
              Abbrechen
            </Button>
            <Button id ="CreateDegreeCourseApplicationCreateButton" variant="primary" onClick={this.handleCreateApplication}>
              Bewerbung erstellen
            </Button>
          </Modal.Footer>
          
        </Modal>
        </div>
    );
}
}
const mapStateToProps = (state: RootState) => ({
  token: state.auth.token,
  userID: state.auth.userID,
  isAdministrator: state.auth.isAdministrator
});

export default connect(mapStateToProps)(CreateDegreeCourseApplicationDialog);