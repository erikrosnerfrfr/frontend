import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../../main';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import { Card } from 'react-bootstrap';
import UpdateDegreeCourseApplication from './updateDegreeCourseApplication';


interface DegreeCourseApplication {
    id: string;
    applicantUserID: string;
    degreeCourseID: string;
    targetPeriodYear: string;
    targetPeriodShortName: string;
    degreeCourseName: string;
    universityShortName: string;
    departmentShortName: string;
}

const DegreeCourseApplicationManagementPage: React.FC = () => {
  const [applications, setApplications] = useState<DegreeCourseApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const token: string = useSelector((state: RootState) => state.auth.token);
  const isAdmin: boolean = useSelector((state: RootState) => state.auth.isAdministrator);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [applicationToDelete, setApplicationToDelete] = useState<DegreeCourseApplication | null>(null);
  const [deleting, setDeleting] = useState(false);

  const baseUrl: string = import.meta.env.VITE_API_BASE_URL;
  const applicationUrl: string = baseUrl + "degreeCourseApplications";

  useEffect(() => {
    fetchApplications();
  }, []);

   const openDeleteModal: (application: DegreeCourseApplication) => void = (application: DegreeCourseApplication) => {
    setApplicationToDelete(application);
    setShowDeleteModal(true);
  };
  
  const closeDeleteModal = () => {
    setShowDeleteModal(false);
    setApplicationToDelete(null);
    setDeleting(false);
  };

  const fetchApplications = async () => {
    setLoading(true);

    let route : string = applicationUrl;
    if(!isAdmin == true) {route += "/myApplications"}

    const response: Response = await fetch(route, {
        method: 'GET',
        headers: { 
          'Authorization': token || ''
        },
      });

  const data = await response.json();
  setApplications(data);
  console.log(data);
        setLoading(false);
  }
  

  const handleDeleteCourse = async (id: string) => {
    
        setLoading(true);

        const response: Response = await fetch(applicationUrl+'/'+id, {
            method: 'DELETE',
            headers: { 
            'Authorization': token || ''
            },
        });
        console.log(response);
        await fetchApplications();
        setLoading(false);
        closeDeleteModal();
  };
  
  if (loading) {
    return <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-2">Bewerbungsmanagement wird geladen...</p>
              </div>;
  }
  
  return (
    <div id="DegreeCourseApplicationManagementPage">
      <div>
        <h1>Bewerbungs-Management</h1>
      </div>

      <hr></hr>
       
      <div id= "DegreeCourseApplicationManagementPageListComponent">
        <div>
          <h5 className="text-start">Studienbewerbungs-Liste</h5>
          {applications.length < 1 &&
          <h6 className='text-start'> Sie haben noch keine Bewerbungen</h6>}
          <div className="row">
            {applications.map(application => (
              <div 
                className="col-12 col-md-6 col-lg-4 mb-3" 
                key={application.id}
                id={`DegreeCourseApplicationItem${application.id}`}
              >
                <Card className="h-100 text-center p-0">
                  <Card.Header>
                    <Card.Title>
                      <span>{application.applicantUserID}: </span> <span>{application.degreeCourseName}</span>
                    </Card.Title>
                  </Card.Header>
                  <Card.Body className='text-start'>
                    
                    
                    <Card.Text>
                      <strong>User:</strong> <span id="ApplicantUserID">{application.applicantUserID}</span>
                    </Card.Text>
          
                    <Card.Text>
                      <strong>Studiengang:</strong> <span id="DegreeCourseName">{application.degreeCourseName}</span>
                    </Card.Text>
          
                    <Card.Text>
                      <strong>Bewerbungsjahr:</strong> <span id="TargetPeriodYear">{application.targetPeriodYear}</span>
                    </Card.Text>

                    <Card.Text>
                      <strong>Semester:</strong> <span id="TargetPeriodShortName">{application.targetPeriodShortName}</span>
                    </Card.Text>

                    <Card.Text>
                      <strong>Universität:</strong> <span id="UniversityShortName">{application.universityShortName}</span>
                    </Card.Text>

                    <Card.Text>
                      <strong>Fachbereich:</strong> <span id="DepartmentShortName">{application.departmentShortName}</span>
                    </Card.Text>
                    
                  </Card.Body>
                  
                  <Card.Footer className="d-flex justify-content-left align-items-center gap-2 flex-wrap">
                    
                    {isAdmin && <button
                                id={`DegreeCourseApplicationItemDeleteButton${application.id}`}
                                className="btn btn-sm btn-outline-danger"
                                onClick={() => openDeleteModal(application)}
                              >Löschen
                              </button>}

                    <UpdateDegreeCourseApplication
                      name= {application.degreeCourseName}
                      id= {application.id}
                      userID= {application.applicantUserID}
                      degreeCourseID= {application.degreeCourseID}
                      targetPeriodYear= {application.targetPeriodYear}
                      targetPeriodShortName={application.targetPeriodShortName}
                      updateSuccess = {fetchApplications}/>
          
                  </Card.Footer>
                </Card>
          
                
              </div>
            ))}
          </div>
        </div>
      </div>

      <Modal id = {`DeleteDialogDegreeCourseApplication${applicationToDelete?.id}`} show={showDeleteModal} onHide={closeDeleteModal}>
        {applicationToDelete && (
          <div>
          <Modal.Header closeButton>
            <Modal.Title>Bewerbung von {applicationToDelete.applicantUserID} zum Studiengang {applicationToDelete.degreeCourseName} wirklich löschen?</Modal.Title>
          </Modal.Header>
          
          <Modal.Body>
            <small>diese Aktion ist nicht rückgängig zu machen!</small>

             {deleting && (
              <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Lädt...</span>
                </div>
                <p className="mt-2">Löschvorgang wird durchgeführt...</p>
              </div>
            )}
          </Modal.Body>

          <Modal.Footer>
            <Button id= "DeleteDialogCancelButton" variant="secondary" onClick={closeDeleteModal}>
              Abbrechen
            </Button>
            <Button id ="DeleteDialogConfirmButton" variant="primary" onClick={()=>handleDeleteCourse(applicationToDelete.id)}>
            Löschen
            </Button>
          </Modal.Footer>
            </div>
        )}
          
        </Modal>
    </div>
    
  );
};

export default DegreeCourseApplicationManagementPage;