import React, { Component } from "react";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';

import { connect } from 'react-redux';
import {
  loginStart,
  loginSuccess,
  loginFailure 
} from '../../slices/authSlice';

interface DispatchProps {
  loginStart: (credentials: { userID: string, password: string }) => void;
  loginSuccess: (payload: { userID: string, token: string, isAdministrator: boolean }) => void;
  loginFailure: () => void;
}

interface LoginDialogState {
  showModal: boolean;
  userID: string;
  password: string;
  error: string | null;
  isLoading: boolean;
}

class LoginDialog extends Component<DispatchProps, LoginDialogState> {
  state = {
    showModal: false,
    userID: '',
    password: '',
    error: null as string | null,
    isLoading: false
  };

  baseUrl: string = import.meta.env.VITE_API_BASE_URL;
  LOGIN_URL: string = this.baseUrl+"authenticate";
  USER_URL: string = this.baseUrl+"users/";

  resetUserData = () => {
    this.setState({ userID: '',
                    password: '' })
  }

  handleShow = () => {
    this.setState({ showModal: true });
  };

  handleClose = () => {
    this.setState({ showModal: false, isLoading: false });
  };

  handleUserIDChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ userID: e.target.value });
  };

  handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ password: e.target.value });
  };

  handleLogin = async () => {
      console.log(this.LOGIN_URL)

    this.setState({isLoading: true});

  const credentials = {
    userID: this.state.userID,
    password: this.state.password
  };

  const { loginStart, loginSuccess, loginFailure } = this.props;

  loginStart(credentials); //informiert store

  const authHeader = 'Basic ' + btoa(credentials.userID + ':' + credentials.password);
  console.log(authHeader)

  try {

  const response: Response = await fetch(this.baseUrl+"authenticate", {
    method: 'GET',
    headers: { 'Authorization': authHeader},
  });

    console.log('Response Status:', response.status);
    console.log('Response OK?', response.ok);

    if(response.ok) {
       const tokenHeader: string = response.headers.get('Authorization');
       console.log(tokenHeader);

      const data = await response.json();
      console.log('data in json:', data);

      const allUserAttributeResponse: Response = await fetch(this.USER_URL+credentials.userID, {
        method: 'GET',
        headers:{'Authorization': tokenHeader,
                  'Content-Type':'application/json'
        }}
      )

      const allAttributeData = await allUserAttributeResponse.json();
      console.log(allAttributeData);

      const isAdministrator: boolean = allAttributeData.isAdministrator;
      

      loginSuccess({ userID: credentials.userID, token: tokenHeader, isAdministrator: isAdministrator });
      this.setState({isLoading: false});
      
      this.handleClose();
    }
    else {
      const errorText: string = await response.text();
      console.error('Login fehlgeschlagen:', response.status, errorText);
      
      this.setState({ 
        error: `Login fehlgeschlagen: ${response.status} - ${errorText}`,
      });

      this.setState({isLoading: false});
      loginFailure();
    }

    
}catch(error: any) {
      console.error('Login fehlgeschlagen:', error);
    };
};

  render() {
    const { error, isLoading } = this.state;
    return (
      <div id ="LoginDialogButtonAndDialog" className="d-grid gap-2">
         
        <Button size="lg" id = "OpenLoginDialogButton" variant="primary" onClick={this.handleShow}>
          Login
        </Button>

        <Modal id = "LoginDialog" show={this.state.showModal} onHide={this.handleClose}>
          
          <Modal.Header closeButton>
            <Modal.Title>Login</Modal.Title>
          </Modal.Header>
          
          <Modal.Body>
            {error && (
              <div className="alert alert-danger">
                <strong>Fehler!</strong> {error}
              </div>
            )}
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>UserID</Form.Label>
                <Form.Control id = "LoginDialogUserIDText"
                  type="text"
                  placeholder="UserID eingeben"
                  value={this.state.userID}
                  onChange={this.handleUserIDChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Passwort</Form.Label>
                <Form.Control id ="LoginDialogPasswordText"
                  type="password"
                  placeholder="Passwort"
                  value={this.state.password}
                  onChange={this.handlePasswordChange}
                  disabled={isLoading}
                />
              </Form.Group>
            </Form>

             {isLoading && (
              <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-2">Login wird durchgeführt...</p>
              </div>
            )}
          </Modal.Body>

          <Modal.Footer>
            <Button variant="secondary" onClick={this.handleClose}>
              Abbrechen
            </Button>
            <Button id ="PerformLoginButton" variant="primary" onClick={this.handleLogin}>
              Login ausführen
            </Button>
          </Modal.Footer>
          
        </Modal>
      </div>
    );
  }
}

const mapDispatchToProps: DispatchProps = {
  loginStart,
  loginSuccess,
  loginFailure,
};

export default connect(
  null,
  mapDispatchToProps
)(LoginDialog);