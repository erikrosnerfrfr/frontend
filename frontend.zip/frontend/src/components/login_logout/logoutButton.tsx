
import { Component } from "react";
import Button from 'react-bootstrap/Button';
import { logout } from '../../slices/authSlice';
import { connect } from 'react-redux';

interface PropsFromRedux {
  logout: () => void
}
interface DispatchProps extends PropsFromRedux{}

class LogoutButton extends Component <DispatchProps> {

  handleLogout = async () => {
    this.props.logout();
  };
  
  render() {
    return (
      <Button className="btn btn-secondary" id = "LogoutButton" onClick={this.handleLogout}>
            logout
        </Button>
    )
  }
}

const mapDispatchToProps: DispatchProps = {
  logout
};

export default connect(
  null,
  mapDispatchToProps 
)(LogoutButton);
