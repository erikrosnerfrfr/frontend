import { Button, Form, Modal } from "react-bootstrap";
import { RootState } from '../../main';
import React, { Component } from "react";
import { connect } from "react-redux";

interface CreateUserDialogState {
  showModal: boolean;
  userID: string;
  firstName: string;
  lastName: string;
  password: string;
  isAdministrator: boolean;
  error: string | null;
  isLoading: boolean;
}

interface PropsFromRedux {
  token: string | null;
}

interface OwnProps {
  createSuccess: () => Promise<void>
}

type CreateUserDialogProps = PropsFromRedux & OwnProps;

class CreateUserDialog extends Component <CreateUserDialogProps, CreateUserDialogState>{
  state = {
    showModal: false,
    userID: '',
    firstName:'',
    lastName:'',
    password: '',
    isAdministrator: false,
    error: null as string | null,
    isLoading: false
  };

  resetUserData = () => {
    this.setState({ userID: '',
                    password: '' })
  }

  baseUrl: string = import.meta.env.VITE_API_BASE_URL;
  createUser_URL: string = this.baseUrl+"users";
    

  handleShow = () => {
    this.setState({ showModal: true });
  };

  handleClose = () => {
    this.setState({ showModal: false });
  };

  handleUserIDChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ userID: e.target.value });
  };

  handleFirstNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ firstName: e.target.value });
  };

  handleLastNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ lastName: e.target.value });
  };

  handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ password: e.target.value });
  };

  handleIsAdminChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ isAdministrator: e.target.checked });
  };
  

  handleCreateUser = async () => {

    this.setState({isLoading: true});
    const token: string = this.props.token;

  try {

  const response: Response = await fetch(this.createUser_URL, {
    method: 'POST',
    headers: {'Authorization': token || '',
              'Content-Type': 'application/json'
    },
    body: JSON.stringify({userID: this.state.userID,
                          firstName: this.state.firstName,
                          lastName: this.state.lastName,
                          password: this.state.password,
                          isAdministrator: this.state.isAdministrator
    })
    
  });

    console.log('Response Status:', response.status);
    console.log('Response OK?', response.ok);

    if(response.ok) {

      if (this.props.createSuccess) {
        this.props.createSuccess();
      }

      this.setState({isLoading: false});
      
      this.handleClose();
    }
    else {
      const errorText: string = await response.text();
      console.error('Erstellen fehlgeschlagen:', response.status, errorText);
      
      this.setState({ 
        error: `Erstellen fehlgeschlagen: ${response.status} - ${errorText}`,
      });

      this.setState({isLoading: false});
    }

    
}catch(error: any) {
      console.error('Erstellen fehlgeschlagen:', error);
    };
};

 render() {
    const { error, isLoading } = this.state;
    return (

        <div id = "createUserContainer">
          <Button id = "UserManagementPageCreateUserButton" variant="primary" onClick={this.handleShow}>
            Neuen User erstellen
          </Button>
        <Modal id = "UserManagementPageCreateComponent" show={this.state.showModal} onHide={this.handleClose}>
          
          <Modal.Header closeButton>
            <Modal.Title>Neuen User erstellen</Modal.Title>
          </Modal.Header>
          
          <Modal.Body>
            {error && (
              <div className="alert alert-danger">
                <strong>Fehler!</strong> {error}
              </div>
            )}
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>UserID</Form.Label>
                <Form.Control id = "CreateUserComponentEditUserID"
                  type="text"
                  placeholder="UserID eingeben"
                  value={this.state.userID}
                  onChange={this.handleUserIDChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Vorname</Form.Label>
                <Form.Control id = "CreateUserComponentEditFirstName"
                  type="text"
                  placeholder="Vorname eingeben"
                  value={this.state.firstName}
                  onChange={this.handleFirstNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Nachname</Form.Label>
                <Form.Control id = "CreateUserComponentEditLastName"
                  type="text"
                  placeholder="Nachname eingeben"
                  value={this.state.lastName}
                  onChange={this.handleLastNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Passwort</Form.Label>
                <Form.Control id ="CreateUserComponentEditPassword"
                  type="password"
                  placeholder="Passwort eingeben"
                  value={this.state.password}
                  onChange={this.handlePasswordChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Adminrechte</Form.Label>
                <Form.Check id ="CreateUserComponentEditIsAdministrator"
                  type="checkbox"
                  checked={this.state.isAdministrator}
                  onChange={this.handleIsAdminChange}
                  disabled={isLoading}
                />
              </Form.Group>
            </Form>

             {isLoading && (
              <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-2">Erstellung wird durchgeführt...</p>
              </div>
            )}
          </Modal.Body>

          <Modal.Footer>
            <Button id= "OpenUserManagementPageListComponentButton" variant="secondary" onClick={this.handleClose}>
              Abbrechen
            </Button>
            <Button id ="CreateUserComponentCreateUserButton" variant="primary" onClick={this.handleCreateUser}>
              User erstellen
            </Button>
          </Modal.Footer>
          
        </Modal>
        </div>
    );
}
}
const mapStateToProps = (state: RootState) => ({
  token: state.auth.token
});

export default connect(mapStateToProps)(CreateUserDialog);