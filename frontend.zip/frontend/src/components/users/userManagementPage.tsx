import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../../main';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import CreateUserDialog from './createNewUserDialog';
import UpdateUserDialog from './updateUserDialog';
import { Card } from 'react-bootstrap';

interface User {
  userID: string;
  firstName: string;
  lastName: string;
  password: string;
  isAdministrator: boolean;
}

const UserManagementPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const token: string = useSelector((state: RootState) => state.auth.token);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [deleting, setDeleting] = useState(false);

  const baseUrl: string = import.meta.env.VITE_API_BASE_URL;
  const userUrl: string = baseUrl+"users";

  useEffect(() => {
    fetchUsers();
  }, []);

   const openDeleteModal = (user: User) => {
    setUserToDelete(user);
    setShowDeleteModal(true);
  };

  const closeDeleteModal = () => {
    setShowDeleteModal(false);
    setUserToDelete(null);
    setDeleting(false);
  };

  const fetchUsers = async () => {
    setLoading(true);

    const response: Response = await fetch(userUrl, {
        method: 'GET',
        headers: { 
          'Authorization': token || '',
          'Content-Type': 'application/json'
        },
      });

  const data = await response.json();
  setUsers(data);
      setLoading(false);
  }
  

  const handleDeleteUser = async (userID: string) => {
    
        setLoading(true);

        const response: Response = await fetch(userUrl+'/'+userID, {
            method: 'DELETE',
            headers: { 
            'Authorization': token || ''
            },
        });
        console.log(response);
        await fetchUsers();
        setLoading(false);
        closeDeleteModal();
  };
  
  if (loading) {
    return <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-2">User Management wird geladen...</p>
              </div>;
  }
  
  return (
    <div id="UserManagementPage">
      <div>
        <h1>User Management</h1>
      </div>
      
      <CreateUserDialog createSuccess={fetchUsers}/>
      <hr></hr>
      <div id= "UserManagementPageListComponent">
         <div className="row">
            <h5 className='text-start'>User Liste</h5>
  {users.map(user => (
    <div 
      className="col-12 col-sm-10 col-md-6 col-lg-4 mb-4" 
      key={user.userID}
      id={`UserItem${user.userID}`}
      style={{ minWidth: '300px', maxWidth: '450px' }}
    >
      <Card className="h-100 text-center p-0" style={{ minWidth: '280px' }}>

        <Card.Header>
          <Card.Title className='text-start'>
            <span id="FirstName">{user.firstName}</span> <span id="LastName">{user.lastName}</span>
          </Card.Title>
        </Card.Header>
        <Card.Body className='text-start'>
          
          
          <Card.Text>
            <strong>UserID:</strong> <span id="UserID">{user.userID}</span>
          </Card.Text>
          
          <Card.Text>
            <strong>Status:</strong> 
            <span id="IsAdministrator" className={`ms-1 badge ${user.isAdministrator ? 'bg-primary' : 'bg-secondary'}`}>
              {user.isAdministrator ? 'Administrator' : 'Nutzer'}
            </span>
          </Card.Text>
        </Card.Body>
        
        <Card.Footer className="d-flex justify-content-left gap-2">
          <UpdateUserDialog 
            userID={user.userID}
            firstName={user.firstName}
            lastName={user.lastName}
            isAdministrator={user.isAdministrator}
            updateSuccess={fetchUsers}
          />
          
          <button
            id={`UserItemDeleteButton${user.userID}`}
            className="btn btn-sm btn-outline-danger"
            onClick={() => openDeleteModal(user)}
          >
            Löschen
          </button>
        </Card.Footer>
      </Card>
    </div>
  ))}
</div>
      </div>

      <Modal id = {`DeleteDialogUser${userToDelete?.userID}`} show={showDeleteModal} onHide={closeDeleteModal}>
        {userToDelete && (
          <div>
          <Modal.Header closeButton>
            <Modal.Title>User {userToDelete.firstName} {userToDelete.lastName} wirklich löschen?</Modal.Title>
          </Modal.Header>
          
          <Modal.Body>
            <small>diese Aktion ist nicht rückgängig zu machen!</small>

             {deleting && (
              <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Lädt...</span>
                </div>
                <p className="mt-2">Löschvorgang wird durchgeführt...</p>
              </div>
            )}
          </Modal.Body>

          <Modal.Footer>
            <Button id= "DeleteDialogCancelButton" variant="secondary" onClick={closeDeleteModal}>
              Abbrechen
            </Button>
            <Button id ="DeleteDialogConfirmButton" variant="primary" onClick={()=>handleDeleteUser(userToDelete.userID)}>
            Löschen
            </Button>
          </Modal.Footer>
            </div>
        )}
          
        </Modal>
    </div>
    
  );
};

export default UserManagementPage;