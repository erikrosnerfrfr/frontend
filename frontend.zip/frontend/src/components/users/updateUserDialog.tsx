import { Button, Form, Modal } from "react-bootstrap";
import { RootState } from '../../main';
import React, { Component } from "react";
import { connect } from "react-redux";

interface UpdateUserDialogState {
  showModal: boolean;
  userID: string;
  firstName: string;
  lastName: string;
  password: string;
  isAdministrator: boolean;
  error: string | null;
  isLoading: boolean;
}

interface PropsFromRedux {
  token: string | null;
  userID: string | null;
}

interface OwnProps {
  updateSuccess: () => Promise<void>;
  userID: string;
  firstName: string | null;
  lastName: string | null;
  isAdministrator: boolean;
}

type UpdateUserDialogProps = PropsFromRedux & OwnProps;

class UpdateUserDialog extends Component <UpdateUserDialogProps, UpdateUserDialogState>{
  state = {
    showModal: false,
    userID: this.props.userID,
    firstName:this.props.firstName,
    lastName:this.props.lastName,
    password: '',
    isAdministrator: this.props.isAdministrator,
    error: null as string | null,
    isLoading: false
  };

  resetUserData = () => {
    this.setState({ userID: '',
                    password: '' })
  }

  baseUrl: string = import.meta.env.VITE_API_BASE_URL;
  updateUser_URL: string = this.baseUrl+"users/"+this.props.userID;
    

  handleShow = () => {
    this.setState({ showModal: true });
  };

  handleClose = () => {
    this.setState({ showModal: false });
  };

  handleUserIDChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ userID: e.target.value });
  };

  handleFirstNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ firstName: e.target.value });
  };

  handleLastNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ lastName: e.target.value });
  };

  handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ password: e.target.value });
  };

  handleIsAdminChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ isAdministrator: e.target.checked });
  };
  

  handleUpdateUser = async () => {

    this.setState({isLoading: true});
    const token: string = this.props.token;

  try {

  const response: Response = await fetch(this.updateUser_URL, {
    method: 'PUT',
    headers: {'Authorization': token || '',
              'Content-Type': 'application/json'
    },
    body: JSON.stringify({userID: this.state.userID,
                          firstName: this.state.firstName,
                          lastName: this.state.lastName,
                          password: this.state.password,
                          isAdministrator: this.state.isAdministrator
    })
    
  });

    console.log('Response Status:', response.status);
    console.log('Response OK?', response.ok);

    if(response.ok) {

      if (this.props.updateSuccess) {
        this.props.updateSuccess();
      }

      this.setState({isLoading: false});
      
      this.handleClose();
      alert("User erfolgreich bearbeitet");
    }
    else {
      const errorText: string = await response.text();
      console.error('Bearbeitung fehlgeschlagen:', response.status, errorText);
      
      this.setState({ 
        error: `Bearbeitung fehlgeschlagen: ${response.status} - ${errorText}`,
      });

      this.setState({isLoading: false});
    }

    
}catch(error: any) {
      console.error('Login fehlgeschlagen:', error);
    };
};

 render() {
    const { error, isLoading } = this.state;
    return (

        <div id = "updateUserContainer">
          <Button id={`UserItemEditButton${this.props.userID}`} variant="primary" onClick={this.handleShow}>
            bearbeiten
          </Button>
        <Modal id = "UserManagementPageEditComponent" show={this.state.showModal} onHide={this.handleClose}>
          
          <Modal.Header closeButton>
            <Modal.Title>Bearbeiten von User {this.state.userID}</Modal.Title>
          </Modal.Header>
          
          <Modal.Body>
            {error && (
              <div className="alert alert-danger">
                <strong>Fehler!</strong> {error}
              </div>
            )}
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>UserID</Form.Label>
                <Form.Control id = "EditUserComponentEditUserID"
                  type="text"
                  placeholder="UserID eingeben"
                  value={this.props.userID}
                  onChange={this.handleUserIDChange}
                  disabled={true}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Vorname</Form.Label>
                <Form.Control id = "EditUserComponentEditFirstName"
                  type="text"
                  placeholder="Vorname eingeben"
                  value={this.state.firstName}
                  onChange={this.handleFirstNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Nachname</Form.Label>
                <Form.Control id = "EditUserComponentEditLastName"
                  type="text"
                  placeholder="Nachname eingeben"
                  value={this.state.lastName}
                  onChange={this.handleLastNameChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Passwort</Form.Label>
                <Form.Control id ="EditUserComponentEditPassword"
                  type="password"
                  placeholder="Passwort eingeben"
                  value={this.state.password}
                  onChange={this.handlePasswordChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Adminrechte</Form.Label>
                <Form.Check id ="EditUserComponentEditIsAdministrator"
                  type="checkbox"
                  checked={this.state.isAdministrator}
                  onChange={this.handleIsAdminChange}
                  disabled={isLoading}
                />
              </Form.Group>
            </Form>

             {isLoading && (
              <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-2">Bearbeitung wird durchgeführt...</p>
              </div>
            )}
          </Modal.Body>

          <Modal.Footer>
            <Button id= "OpenUserManagementPageListComponentButton" variant="secondary" onClick={this.handleClose}>
              Abbrechen
            </Button>
            <Button id ="EditUserComponentSaveUserButton" variant="primary" onClick={this.handleUpdateUser}>
              Bearbeitung speichern
            </Button>
          </Modal.Footer>
          
        </Modal>
        </div>
    );
}
}
const mapStateToProps = (state: RootState) => ({
  token: state.auth.token
});

export default connect(mapStateToProps)(UpdateUserDialog);