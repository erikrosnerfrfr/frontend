import reactLogo from '../assets/react.svg'
import viteLogo from '/vite.svg'
import LoginDialog from './login_logout/loginDialog';
import { Component } from "react";

class LandingPage extends Component {

  render() {
    return (
    <div id ="LandingPage">
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Studienportal</h1>
      <h3>mit Vite + React</h3>
      <p></p>
      <p>bitte einloggen.</p>
      <div>        
        <LoginDialog />
      </div>
    </div>
    )
  }
}

export default LandingPage
