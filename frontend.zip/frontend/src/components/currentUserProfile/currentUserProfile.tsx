import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../../main';
import UpdateUserDialog from '../users/updateUserDialog';

interface User {
  userID: string;
  firstName: string;
  lastName: string;
  password: string;
  isAdministrator: boolean;
}

const CurrentUserProfile: React.FC = () => {
  const [user, setUsers] = useState<User>();
  const [loading, setLoading] = useState(true);
  const token: string = useSelector((state: RootState) => state.auth.token);
  const userID: string = useSelector((state: RootState) => state.auth.userID);

  const baseUrl: string = import.meta.env.VITE_API_BASE_URL;

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);

    const response: Response = await fetch(baseUrl + 'publicUsers/'+ userID, {
        method: 'GET',
        headers: { 
          'Authorization': token || '',
          'Content-Type': 'application/json'
        },
      });

  const data = await response.json();
  console.log(data);
  
  setUsers(data);
  setLoading(false);
  }
  
  if (loading) {
    return <div className="text-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              <p className="mt-2">Profil wird geladen...</p>
            </div>;
  }
  
  return (
    <div id="CurrentUserProfile">
      <hr></hr>
      <div id= "CurrentUserProfilePageListComponent">          
        <div className="row">
          <div 
            key={user.userID}
            id={`UserItem${user.userID}`}
          > 
            <h2> Dein Profil</h2> 
       
            <div><strong>UserID:</strong> <span id="UserID">{user.userID}</span></div>
          
          
            <div><strong>Vorname:</strong> <span id="FirstName">{user.firstName}</span></div>
         
            <div><strong>Nachname:</strong> <span id="LastName">{user.lastName}</span></div>
         
            <div><strong>Status:</strong> 
            <span id="IsAdministrator" className={`ms-1 badge ${user.isAdministrator ? 'bg-primary' : 'bg-secondary'}`}>
              {user.isAdministrator ? 'Administrator' : 'Nutzer'}
            </span></div>
            <p></p>
          
          <UpdateUserDialog 
            userID={user.userID}
            firstName={user.firstName}
            lastName={user.lastName}
            isAdministrator={user.isAdministrator}
            updateSuccess={fetchUsers}
          />
        </div>
      </div>
    </div>
    <hr></hr>
  </div>
    
  );
};

export default CurrentUserProfile;