import { useSelector } from 'react-redux';
import { RootState } from './main';
import './App.css'
import LandingPage from './components/landingPage';
import HomePage from './components/homePage';
import UserManagement from './components/users/userManagementPage';
import DegreeCourseManagement from './components/degreeCourses/degreeCourseManagementPage';
import DegreeCourseApplicationManagement from './components/degreeCourseApplications/degreeCourseApplicationManagementPage';
import { useNavigate, Route, Routes } from 'react-router-dom';
import { useEffect } from 'react';
import NavBar from './components/navBar';
function App() {
  const loggedIn: string = useSelector((state: RootState) => state.auth.userID);
  const isAdmin: boolean = useSelector((state: RootState) => state.auth.isAdministrator);
  const navigate = useNavigate();

  useEffect(() => {
    if (!loggedIn) {
      navigate("/");
    }

    else if (loggedIn && window.location.pathname === "/") {
      navigate("/home");
    }
  }, [loggedIn, navigate]);

  if (loggedIn) {
    return (
      <div>
        <NavBar></NavBar>
        <div className="main-content-wrapper"> {/*Idee main-content-wrapper von Google Gemini!*/}
        <Routes>
          <Route path="/" element={<HomePage />} />
          
          <Route 
            path="/userManagement"
            element={
              isAdmin ? <UserManagement /> : <HomePage />
            } 
          />

          <Route 
            path="/degreeCourseManagement"
            element={ <DegreeCourseManagement/>}
          />

          <Route 
            path="/degreeCourseApplicationManagement"
            element={ <DegreeCourseApplicationManagement/>}
          />
          <Route path="/home" element={<HomePage />} />
        </Routes>
        </div>
      </div>
    );
  }
  return (
    <LandingPage/>
  )
}


export default App
