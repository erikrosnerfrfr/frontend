import { createSlice, PayloadAction } from '@reduxjs/toolkit'

interface AuthState {
  showLoginDialog: boolean
  loginPending: boolean
  userID: string | null
  token: string | null
  isAdministrator: boolean
}

const initialState: AuthState = {
  showLoginDialog: false,
  loginPending: false,
  userID: null,
  token: null,
  isAdministrator: false
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    showLoginDialog(state) {
      state.showLoginDialog = true
    },
    hideLoginDialog(state) {
      state.showLoginDialog = false
    },
    
    loginStart(state, action: PayloadAction<{userID: string, password: string}>) {
      state.loginPending = true
    },
    loginSuccess(state, action: PayloadAction<{userID: string, token: string, isAdministrator: boolean}>) {
      state.loginPending = false
      state.userID = action.payload.userID
      state.token = action.payload.token
      state.isAdministrator = action.payload.isAdministrator
      state.showLoginDialog = false
    },
    loginFailure(state) {
      state.loginPending = false
    },
    
    logout(state) {
      state.userID = null
      state.token = null
      state.isAdministrator = false
    }
  }
})

export const {
  showLoginDialog,
  hideLoginDialog,
  loginStart,
  loginSuccess,
  loginFailure,
  logout
} = authSlice.actions

export default authSlice.reducer