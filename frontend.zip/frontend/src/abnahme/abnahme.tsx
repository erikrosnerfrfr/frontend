import React, { useEffect, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

import LogoutButton from "../components/login_logout/logoutButton";
import { RootState } from "../main";

const NavDialog: React.FC = () => {
  const isAdmin = useSelector(
    (state: RootState) => state.auth.isAdministrator
  );

  const [showModal, setShowModal] = useState(false);

  return (
    <div>
      <Button variant="primary" onClick={() => setShowModal(true)}>
        Navigation
      </Button>

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header>
          <Modal.Title>Navigation</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <Link
            to="/home"
            className="btn btn-secondary"
            onClick={() => setShowModal(false)}
          >
            Startseite
          </Link>

          {isAdmin && (
            <Link
              to="/userManagement"
              className="btn btn-outline-primary"
              onClick={() => setShowModal(false)}
            >
              User Management
            </Link>
          )}

          <Button onClick={()=>setShowModal(false)}>
            abbrechen
          </Button>

          <LogoutButton />

        </Modal.Body>
      </Modal>
    </div>
  );
};

export default NavDialog;
